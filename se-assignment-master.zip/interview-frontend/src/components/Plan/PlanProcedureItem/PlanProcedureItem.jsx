import React, { useState,useEffect } from "react";
import ReactSelect from "react-select";
import { addUsersToPlanProcedure, getPlanProcedureUsers } from "../../../api/api";
const PlanProcedureItem = ({ planId, procedure, users }) => {
    const [selectedUsers, setSelectedUsers] = useState();

    useEffect(() => {
        (async () => {
            const users = await getPlanProcedureUsers(planId, procedure.procedureId);
            var mappedUsers = [];
            users.map((u) => mappedUsers.push({ label: u.user.name, value: u.user.userId }));
            setSelectedUsers(mappedUsers);
        })();
    }, []);

    const handleAssignUsersToProcedure = async (e) => {
        var mappedUsers = [];
            e.map((u) => mappedUsers.push(u.value));
        const response = await addUsersToPlanProcedure(planId, procedure.procedureId, mappedUsers);
        if (response)
            setSelectedUsers(e);
        else {
            /*
            display error message and keep prev selection(dont update state)
            */
        }
    };

    return (
        <div className="py-2">
            <div>
                {procedure.procedureTitle}
            </div>

            <ReactSelect
                className="mt-2"
                placeholder="Select User to Assign"
                isMulti={true}
                options={users}
                value={selectedUsers}
                onChange={(e) => handleAssignUsersToProcedure(e)}
            />
        </div>
    );
};

export default PlanProcedureItem;

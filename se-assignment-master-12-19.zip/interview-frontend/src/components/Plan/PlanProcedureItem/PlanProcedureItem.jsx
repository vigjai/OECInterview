import React, { useState, useEffect } from "react";
import ReactSelect from "react-select";
import { addUsersToPlanProcedure, getPlanProcedureUsers } from "../../../api/api";
import { useErrorBoundary } from "react-error-boundary";

const PlanProcedureItem = ({ planId, procedure, users }) => {
    const [selectedUsers, setSelectedUsers] = useState();
    const { showBoundary } = useErrorBoundary();

    useEffect(() => {
        (async () => {
            try {
                const users = await getPlanProcedureUsers(planId, procedure.procedureId);
                var mappedUsers = [];
                users.map((u) => mappedUsers.push({ label: u.user.name, value: u.user.userId }));
                setSelectedUsers(mappedUsers);
            }
            catch (e) {
                showBoundary(e);
            }
        })();
    }, []);

    const handleAssignUsersToProcedure = async (e) => {
        try {
            var mappedUsers = [];
            e.map((u) => mappedUsers.push(u.value));
            addUsersToPlanProcedure(planId, procedure.procedureId, mappedUsers);
            setSelectedUsers(e);
        }
        catch (e) {
            showBoundary(e);
        }
    };

    return (
        <div className="py-2">
            <div>
                {procedure.procedureTitle}
            </div>

            <ReactSelect
                className="mt-2"
                placeholder="Select User to Assign"
                isMulti={true}
                options={users}
                value={selectedUsers}
                onChange={handleAssignUsersToProcedure}
            />
        </div>
    );
};

export default PlanProcedureItem;

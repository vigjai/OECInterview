import React from "react";
import Navbar from "./Navbar/Navbar";
//import ErrorBoundary from "../ErrorBoundary/ErrorBoundary";
import ErrorPage from "../Error/Error";
import { ErrorBoundary } from "react-error-boundary";

const Layout = ({ children }) => {
    return (
        <ErrorBoundary fallback={<ErrorPage />}>
            <div className="App">
                <Navbar />
                {children}
            </div>
        </ErrorBoundary>
    );
};

export default Layout;

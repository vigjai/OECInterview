﻿using FluentAssertions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Moq;
using RL.Backend.Commands;
using RL.Backend.Commands.Handlers.Plans;
using RL.Backend.Commands.Handlers.UserPlanProcedure;
using RL.Backend.Exceptions;
using RL.Data;

namespace RL.Backend.UnitTests
{
    [TestClass]
    public class AssignUserToPlanProcedureTest
    {
        Mock<RLContext>? _context;
        AssignUserToPlanProcedureHandler? _handler;

        [TestInitialize]
        public void Initialize()
        {
            _context = new Mock<RLContext>();
            _handler = new AssignUserToPlanProcedureHandler(_context.Object);
        }

        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(int.MinValue)]
        public async Task AssignUserToPlanProcedureTests_InvalidPlanId_ReturnsBadRequest(int planId)
        {
            _context = new Mock<RLContext>();
            _handler = new AssignUserToPlanProcedureHandler(_context.Object);
            var request = new AssignUserToPlanProcedureCommand()
            {
                PlanId = planId,
                ProcedureId = 1,
                AssignedUsers = new List<int> { 1, 2 }
            };
            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType(typeof(BadRequestException));
            result.Succeeded.Should().BeFalse();
        }

        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(int.MinValue)]
        public async Task AssignUserToPlanProcedureTests_InvalidProcedureId_ReturnsBadRequest(int procedureId)
        {
            _context = new Mock<RLContext>();
            _handler = new AssignUserToPlanProcedureHandler(_context.Object);
            var request = new AssignUserToPlanProcedureCommand()
            {
                PlanId = 1,
                ProcedureId = procedureId,
                AssignedUsers = new List<int> { 1, 2 }
            };
            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType(typeof(BadRequestException));
            result.Succeeded.Should().BeFalse();
        }

        [TestMethod]
        [DataRow(new[] { -1 })]
        [DataRow(new[] { 0 })]
        [DataRow(new[] { int.MinValue })]
        [DataRow(new[] { -1, 1 })]
        public async Task AssignUserToPlanProcedureTests_InvalidUserId_ReturnsNotFound(int[] assignedUsers)
        {
            var context = DbContextHelper.CreateContext();
            _handler = new AssignUserToPlanProcedureHandler(context);
            var request = new AssignUserToPlanProcedureCommand()
            {
                PlanId = 1,
                ProcedureId = 1,
                AssignedUsers = assignedUsers.OfType<int>().ToList()
            };

            context.Plans.Add(new Data.DataModels.Plan
            {
                PlanId = 1
            });
            context.Procedures.Add(new Data.DataModels.Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });
            context.PlanProcedures.Add(new Data.DataModels.PlanProcedure
            {
                ProcedureId = 1,
                PlanId = 1
            });
            context.Users.Add(new Data.DataModels.User
            {
                UserId = 1,
                Name = "Test User",
            });
            context.Users.Add(new Data.DataModels.User
            {
                UserId = 2,
                Name = "Test User",
            });
            await context.SaveChangesAsync();

            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType(typeof(NotFoundException));
            result.Succeeded.Should().BeFalse();
        }

        [TestMethod]
        [DataRow(new[] { 1 })]
        [DataRow(new[] { 1, 2 })]        
        public async Task AssignUserToPlanProcedureTests_AddUsers_ReturnsSuccess(int[] assignedUsers)
        {
            var context = DbContextHelper.CreateContext();
            _handler = new AssignUserToPlanProcedureHandler(context);
            var request = new AssignUserToPlanProcedureCommand()
            {
                PlanId = 1,
                ProcedureId = 1,
                AssignedUsers = assignedUsers.OfType<int>().ToList()
            };

            context.Plans.Add(new Data.DataModels.Plan
            {
                PlanId = 1
            });
            context.Procedures.Add(new Data.DataModels.Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });
            context.PlanProcedures.Add(new Data.DataModels.PlanProcedure
            {
                ProcedureId = 1,
                PlanId = 1
            });
            context.Users.Add(new Data.DataModels.User
            {
                UserId = 1,
                Name = "Test User",
            });
            context.Users.Add(new Data.DataModels.User
            {
                UserId = 2,
                Name = "Test User",
            });
            await context.SaveChangesAsync();

            var result = await _handler.Handle(request, new CancellationToken());

            result.Value.Should().BeOfType(typeof(Unit));
            result.Succeeded.Should().BeTrue();
        }

        [TestMethod]
        public async Task AssignUserToPlanProcedureTests_RemoveUsers_ReturnsSuccess()
        {
            var context = DbContextHelper.CreateContext();
            _handler = new AssignUserToPlanProcedureHandler(context);
            var request = new AssignUserToPlanProcedureCommand()
            {
                PlanId = 1,
                ProcedureId = 1
            };

            context.Plans.Add(new Data.DataModels.Plan
            {
                PlanId = 1
            });
            context.Procedures.Add(new Data.DataModels.Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });
            context.PlanProcedures.Add(new Data.DataModels.PlanProcedure
            {
                ProcedureId = 1,
                PlanId = 1
            });
            context.Users.Add(new Data.DataModels.User
            {
                UserId = 1,
                Name = "Test User",
            });
            context.Users.Add(new Data.DataModels.User
            {
                UserId = 2,
                Name = "Test User",
            });
            await context.SaveChangesAsync();

            var result = await _handler.Handle(request, new CancellationToken());

            result.Value.Should().BeOfType(typeof(Unit));
            result.Succeeded.Should().BeTrue();
        }
    }
}

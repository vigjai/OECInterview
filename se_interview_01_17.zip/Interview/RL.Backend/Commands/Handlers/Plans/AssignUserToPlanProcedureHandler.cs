﻿using MediatR;
using RL.Backend.Exceptions;
using RL.Backend.Models;
using RL.Data;
using RL.Data.DataModels;

namespace RL.Backend.Commands.Handlers.UserPlanProcedure
{
    public class AssignUserToPlanProcedureHandler : IRequestHandler<AssignUserToPlanProcedureCommand, ApiResponse<Unit>>
    {
        private readonly RLContext _context;

        public AssignUserToPlanProcedureHandler(RLContext context)
        {
            _context = context;
        }

        public async Task<ApiResponse<Unit>> Handle(AssignUserToPlanProcedureCommand request, CancellationToken cancellationToken)
        {
            try
            {
                //Validate request
                if (request.PlanId < 1)
                    return ApiResponse<Unit>.Fail(new BadRequestException("Invalid PlanId"));
                if (request.ProcedureId < 1)
                    return ApiResponse<Unit>.Fail(new BadRequestException("Invalid ProcedureId"));

                var planProcedureUsers = _context.PlanProcedureUsers;

                if (request.AssignedUsers.Count != _context.Users.Count(pp => request.AssignedUsers.Contains(pp.UserId)))
                    return ApiResponse<Unit>.Fail(new NotFoundException($"User(s) not found"));

                var currentList = planProcedureUsers.Where(pp => pp.PlanId == request.PlanId && pp.ProcedureId == request.ProcedureId);
                if (request.AssignedUsers.Any())
                {
                    var incomingList = request.AssignedUsers.Select(userId => new PlanProcedureUser
                    {
                        PlanId = request.PlanId,
                        UserId = userId,
                        ProcedureId = request.ProcedureId
                    });
                    var removeItems = currentList.Except(incomingList);
                    var addItems = incomingList.Except(currentList);
                    if (addItems.Any())
                        planProcedureUsers.AddRange(addItems);
                    if (removeItems.Any())
                        planProcedureUsers.RemoveRange(removeItems);
                }
                else if (currentList.Any())
                {
                    planProcedureUsers.RemoveRange(
                    planProcedureUsers.Where(pp => pp.PlanId == request.PlanId && pp.ProcedureId == request.ProcedureId
                    ));
                }

                await _context.SaveChangesAsync();

                return ApiResponse<Unit>.Succeed(new Unit());
            }
            catch (Exception e)
            {
                return ApiResponse<Unit>.Fail(e);
            }
        }
    }
}
